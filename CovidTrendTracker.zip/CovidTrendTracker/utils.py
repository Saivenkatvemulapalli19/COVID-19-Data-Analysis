import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def format_number(number):
    """Format large numbers with appropriate suffixes"""
    if pd.isna(number) or number == 0:
        return "0"
    
    try:
        number = float(number)
        
        if number >= 1_000_000_000:
            return f"{number / 1_000_000_000:.1f}B"
        elif number >= 1_000_000:
            return f"{number / 1_000_000:.1f}M"
        elif number >= 1_000:
            return f"{number / 1_000:.1f}K"
        else:
            return f"{number:,.0f}"
    except (ValueError, TypeError):
        return str(number)

def calculate_growth_rate(current_value, previous_value):
    """Calculate growth rate between two values"""
    try:
        if previous_value == 0:
            return float('inf') if current_value > 0 else 0
        
        growth_rate = ((current_value - previous_value) / previous_value) * 100
        return round(growth_rate, 2)
    except (ZeroDivisionError, TypeError):
        return 0

def get_country_stats(data, country, date=None):
    """Get statistics for a specific country and date"""
    try:
        if date is None:
            date = data['Date'].max()
        
        country_data = data[
            (data['Country/Region'] == country) & 
            (data['Date'] == date)
        ]
        
        if country_data.empty:
            return None
        
        stats = country_data.iloc[0]
        
        return {
            'confirmed': stats['Confirmed'],
            'deaths': stats['Deaths'],
            'recovered': stats['Recovered'],
            'mortality_rate': stats['Mortality Rate'],
            'recovery_rate': stats['Recovery Rate'],
            'cases_per_million': stats.get('Cases per Million', 0),
            'deaths_per_million': stats.get('Deaths per Million', 0),
            'active_cases': stats['Confirmed'] - stats['Deaths'] - stats['Recovered']
        }
    except Exception as e:
        return None

def calculate_moving_average(data, column, window=7):
    """Calculate moving average for a column"""
    try:
        return data[column].rolling(window=window, min_periods=1).mean()
    except Exception:
        return data[column]

def get_top_countries(data, metric, n=10):
    """Get top N countries by a specific metric"""
    try:
        latest_data = data[data['Date'] == data['Date'].max()]
        
        if metric in ['Cases per Million', 'Deaths per Million']:
            top_countries = latest_data.nlargest(n, metric)['Country/Region'].tolist()
        else:
            country_totals = latest_data.groupby('Country/Region')[metric].sum()
            top_countries = country_totals.nlargest(n).index.tolist()
        
        return top_countries
    except Exception:
        return []

def validate_date_range(start_date, end_date, data):
    """Validate and adjust date range based on available data"""
    try:
        min_date = data['Date'].min()
        max_date = data['Date'].max()
        
        # Adjust start date if before minimum
        if start_date < min_date:
            start_date = min_date
        
        # Adjust end date if after maximum
        if end_date > max_date:
            end_date = max_date
        
        # Ensure start date is before end date
        if start_date >= end_date:
            start_date = max_date - timedelta(days=30)
        
        return start_date, end_date
    except Exception:
        return start_date, end_date

def calculate_doubling_time(data, country, metric='Confirmed'):
    """Calculate doubling time for a specific metric"""
    try:
        country_data = data[data['Country/Region'] == country].sort_values('Date')
        values = country_data[metric].values
        
        # Find the most recent period where cases doubled
        for i in range(len(values) - 1, 0, -1):
            if values[i] >= 2 * values[i-1] and values[i-1] > 0:
                # Calculate daily growth rate
                days = 1
                growth_rate = (values[i] / values[i-1]) - 1
                
                if growth_rate > 0:
                    doubling_time = np.log(2) / np.log(1 + growth_rate)
                    return round(doubling_time, 1)
        
        return None
    except Exception:
        return None

def get_global_summary(data):
    """Get global summary statistics"""
    try:
        latest_data = data[data['Date'] == data['Date'].max()]
        
        summary = {
            'total_confirmed': latest_data['Confirmed'].sum(),
            'total_deaths': latest_data['Deaths'].sum(),
            'total_recovered': latest_data['Recovered'].sum(),
            'countries_affected': latest_data['Country/Region'].nunique(),
            'global_mortality_rate': (latest_data['Deaths'].sum() / latest_data['Confirmed'].sum()) * 100,
            'global_recovery_rate': (latest_data['Recovered'].sum() / latest_data['Confirmed'].sum()) * 100,
            'last_updated': latest_data['Date'].iloc[0].strftime('%Y-%m-%d')
        }
        
        # Calculate active cases
        summary['active_cases'] = (
            summary['total_confirmed'] - 
            summary['total_deaths'] - 
            summary['total_recovered']
        )
        
        return summary
    except Exception:
        return {}

def filter_data_by_population(data, min_population=1000000):
    """Filter countries by minimum population for more meaningful comparisons"""
    try:
        # This would require population data to be meaningful
        # For now, just return the original data
        return data
    except Exception:
        return data

def calculate_weekly_change(data, country, metric='Confirmed'):
    """Calculate week-over-week change for a country"""
    try:
        country_data = data[data['Country/Region'] == country].sort_values('Date')
        
        if len(country_data) < 7:
            return None
        
        latest_value = country_data[metric].iloc[-1]
        week_ago_value = country_data[metric].iloc[-8] if len(country_data) >= 8 else country_data[metric].iloc[0]
        
        if week_ago_value > 0:
            change = ((latest_value - week_ago_value) / week_ago_value) * 100
            return round(change, 2)
        
        return None
    except Exception:
        return None
