import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime, timedelta

class CovidVisualizations:
    def __init__(self, data):
        self.data = data
        self.color_palette = px.colors.qualitative.Set3
    
    def create_line_plot(self, data, countries, metric, view_type):
        """Create line plot for COVID-19 trends"""
        try:
            # Filter data for selected countries
            filtered_data = data[data['Country/Region'].isin(countries)]
            
            # Select the appropriate column based on view type
            if view_type == 'Daily New Cases':
                y_column = f'Daily New {metric}'
                title = f'Daily New {metric} Cases by Country'
            else:
                y_column = metric
                title = f'Cumulative {metric} Cases by Country'
            
            # Create line plot
            fig = px.line(
                filtered_data,
                x='Date',
                y=y_column,
                color='Country/Region',
                title=title,
                labels={
                    'Date': 'Date',
                    y_column: f'{metric} Cases',
                    'Country/Region': 'Country'
                },
                line_shape='spline'
            )
            
            # Update layout
            fig.update_layout(
                height=500,
                hovermode='x unified',
                legend=dict(
                    orientation="h",
                    yanchor="bottom",
                    y=1.02,
                    xanchor="right",
                    x=1
                ),
                xaxis_title="Date",
                yaxis_title=f"{metric} Cases"
            )
            
            # Add range selector
            fig.update_layout(
                xaxis=dict(
                    rangeselector=dict(
                        buttons=list([
                            dict(count=30, label="30d", step="day", stepmode="backward"),
                            dict(count=90, label="3m", step="day", stepmode="backward"),
                            dict(count=180, label="6m", step="day", stepmode="backward"),
                            dict(step="all")
                        ])
                    ),
                    rangeslider=dict(visible=True),
                    type="date"
                )
            )
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating line plot: {str(e)}")
    
    def create_area_chart(self, data, metric):
        """Create area chart for global trends"""
        try:
            # Aggregate global data by date
            global_data = data.groupby('Date').agg({
                'Confirmed': 'sum',
                'Deaths': 'sum',
                'Recovered': 'sum'
            }).reset_index()
            
            # Create area chart
            fig = go.Figure()
            
            if metric == 'Confirmed':
                fig.add_trace(go.Scatter(
                    x=global_data['Date'],
                    y=global_data['Recovered'],
                    fill='tonexty',
                    mode='none',
                    name='Recovered',
                    line_color='green',
                    fillcolor='rgba(0, 255, 0, 0.3)'
                ))
                
                fig.add_trace(go.Scatter(
                    x=global_data['Date'],
                    y=global_data['Deaths'],
                    fill='tonexty',
                    mode='none',
                    name='Deaths',
                    line_color='red',
                    fillcolor='rgba(255, 0, 0, 0.3)'
                ))
                
                active_cases = global_data['Confirmed'] - global_data['Deaths'] - global_data['Recovered']
                fig.add_trace(go.Scatter(
                    x=global_data['Date'],
                    y=active_cases,
                    fill='tonexty',
                    mode='none',
                    name='Active',
                    line_color='orange',
                    fillcolor='rgba(255, 165, 0, 0.3)'
                ))
            else:
                fig.add_trace(go.Scatter(
                    x=global_data['Date'],
                    y=global_data[metric],
                    fill='tozeroy',
                    mode='none',
                    name=metric,
                    line_color='blue' if metric == 'Confirmed' else 'red',
                    fillcolor=f'rgba({"0, 0, 255" if metric == "Confirmed" else "255, 0, 0"}, 0.3)'
                ))
            
            fig.update_layout(
                title=f'Global COVID-19 {metric} Trends',
                xaxis_title='Date',
                yaxis_title='Number of Cases',
                height=400,
                hovermode='x unified'
            )
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating area chart: {str(e)}")
    
    def create_country_heatmap(self, data, metric):
        """Create heatmap of countries by metric"""
        try:
            # Get top 50 countries by metric
            country_data = data.groupby('Country/Region')[metric].sum().sort_values(ascending=False).head(50)
            
            # Reshape for heatmap (10x5 grid)
            countries = country_data.index.tolist()
            values = country_data.values.tolist()
            
            # Pad to make it divisible by 10
            while len(countries) % 10 != 0:
                countries.append('')
                values.append(0)
            
            # Reshape to matrix
            rows = len(countries) // 10
            country_matrix = np.array(countries).reshape(rows, 10)
            value_matrix = np.array(values).reshape(rows, 10)
            
            # Create heatmap
            fig = go.Figure(data=go.Heatmap(
                z=value_matrix,
                text=country_matrix,
                texttemplate="%{text}<br>%{z:,.0f}",
                textfont={"size": 10},
                colorscale='Reds' if metric == 'Deaths' else 'Blues',
                showscale=True,
                colorbar=dict(title=f"{metric} Cases")
            ))
            
            fig.update_layout(
                title=f'Top 50 Countries by {metric} Cases',
                height=400,
                xaxis=dict(showticklabels=False),
                yaxis=dict(showticklabels=False)
            )
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating country heatmap: {str(e)}")
    
    def create_time_heatmap(self, data, countries, metric):
        """Create time series heatmap for selected countries"""
        try:
            # Filter data for selected countries
            filtered_data = data[data['Country/Region'].isin(countries)]
            
            # Pivot data for heatmap
            pivot_data = filtered_data.pivot(
                index='Country/Region',
                columns='Date',
                values=metric
            )
            
            # Sample dates to avoid overcrowding (take every 7th day)
            date_columns = pivot_data.columns[::7]
            pivot_data = pivot_data[date_columns]
            
            # Create heatmap
            fig = go.Figure(data=go.Heatmap(
                z=pivot_data.values,
                x=[d.strftime('%Y-%m-%d') for d in pivot_data.columns],
                y=pivot_data.index,
                colorscale='Viridis',
                showscale=True,
                colorbar=dict(title=f"{metric} Cases")
            ))
            
            fig.update_layout(
                title=f'{metric} Cases Over Time by Country',
                height=max(300, len(countries) * 40),
                xaxis_title='Date',
                yaxis_title='Country'
            )
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating time heatmap: {str(e)}")
    
    def get_country_rankings(self, data, ranking_metric):
        """Get country rankings by specified metric"""
        try:
            if ranking_metric in ['Deaths per Million', 'Cases per Million']:
                # Use per capita metrics
                rankings = data.groupby('Country/Region')[ranking_metric].max().sort_values(ascending=False)
            else:
                # Use absolute numbers
                rankings = data.groupby('Country/Region')[ranking_metric].sum().sort_values(ascending=False)
            
            # Create DataFrame
            rankings_df = pd.DataFrame({
                'Rank': range(1, len(rankings) + 1),
                'Country': rankings.index,
                'Value': rankings.values
            })
            
            # Format values
            if 'Million' in ranking_metric:
                rankings_df['Formatted Value'] = rankings_df['Value'].apply(lambda x: f"{x:,.1f}")
            else:
                rankings_df['Formatted Value'] = rankings_df['Value'].apply(lambda x: f"{x:,.0f}")
            
            return rankings_df
            
        except Exception as e:
            return pd.DataFrame({'Error': [f"Error creating rankings: {str(e)}"]})
    
    def create_comparison_table(self, data, countries):
        """Create comparison table for selected countries"""
        try:
            comparison_data = []
            
            for country in countries:
                country_data = data[data['Country/Region'] == country].iloc[0]
                
                comparison_data.append({
                    'Country': country,
                    'Confirmed': f"{country_data['Confirmed']:,.0f}",
                    'Deaths': f"{country_data['Deaths']:,.0f}",
                    'Recovered': f"{country_data['Recovered']:,.0f}",
                    'Mortality Rate (%)': f"{country_data['Mortality Rate']:.2f}",
                    'Recovery Rate (%)': f"{country_data['Recovery Rate']:.2f}",
                    'Cases per Million': f"{country_data.get('Cases per Million', 0):,.1f}",
                    'Deaths per Million': f"{country_data.get('Deaths per Million', 0):,.1f}"
                })
            
            return pd.DataFrame(comparison_data)
            
        except Exception as e:
            return pd.DataFrame({'Error': [f"Error creating comparison table: {str(e)}"]})
    
    def create_radar_chart(self, data, countries):
        """Create radar chart for country comparison"""
        try:
            fig = go.Figure()
            
            # Metrics for radar chart (normalized)
            metrics = ['Confirmed', 'Deaths', 'Mortality Rate', 'Cases per Million']
            
            for country in countries[:5]:  # Limit to 5 countries for readability
                country_data = data[data['Country/Region'] == country].iloc[0]
                
                # Normalize values (0-100 scale)
                values = []
                for metric in metrics:
                    if metric in ['Mortality Rate']:
                        values.append(min(country_data[metric], 100))
                    elif metric in ['Cases per Million']:
                        max_val = data[metric].max() if not data[metric].isna().all() else 1
                        normalized = (country_data.get(metric, 0) / max_val) * 100
                        values.append(min(normalized, 100))
                    else:
                        max_val = data[metric].max()
                        normalized = (country_data[metric] / max_val) * 100
                        values.append(normalized)
                
                fig.add_trace(go.Scatterpolar(
                    r=values,
                    theta=metrics,
                    fill='toself',
                    name=country,
                    opacity=0.6
                ))
            
            fig.update_layout(
                polar=dict(
                    radialaxis=dict(
                        visible=True,
                        range=[0, 100]
                    )),
                showlegend=True,
                title="Country Comparison (Normalized Metrics)",
                height=500
            )
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating radar chart: {str(e)}")
    
    def create_scatter_plot(self, data, countries):
        """Create scatter plot for recovery vs death rate"""
        try:
            country_data = data[data['Country/Region'].isin(countries)]
            
            fig = px.scatter(
                country_data,
                x='Recovery Rate',
                y='Mortality Rate',
                size='Confirmed',
                color='Country/Region',
                hover_name='Country/Region',
                title='Recovery Rate vs Mortality Rate',
                labels={
                    'Recovery Rate': 'Recovery Rate (%)',
                    'Mortality Rate': 'Mortality Rate (%)'
                }
            )
            
            fig.update_layout(height=500)
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating scatter plot: {str(e)}")
    
    def get_summary_data(self, data):
        """Get summary data for export"""
        try:
            summary = data.groupby('Country/Region').agg({
                'Confirmed': 'sum',
                'Deaths': 'sum',
                'Recovered': 'sum',
                'Mortality Rate': 'mean',
                'Recovery Rate': 'mean',
                'Cases per Million': 'max',
                'Deaths per Million': 'max'
            }).round(2)
            
            summary = summary.sort_values('Confirmed', ascending=False)
            summary.reset_index(inplace=True)
            
            return summary
            
        except Exception as e:
            return pd.DataFrame({'Error': [f"Error creating summary: {str(e)}"]})
    
    def create_trend_forecast(self, data, country, metric, forecast_days):
        """Create trend forecast using moving averages"""
        try:
            country_data = data[data['Country/Region'] == country].sort_values('Date')
            
            if len(country_data) < 14:
                return self._create_error_figure("Insufficient data for forecasting")
            
            # Calculate moving averages
            country_data = country_data.copy()
            country_data['MA_7'] = country_data[metric].rolling(window=7).mean()
            country_data['MA_14'] = country_data[metric].rolling(window=14).mean()
            
            # Simple linear trend for forecast
            recent_data = country_data.tail(14)
            x_vals = np.arange(len(recent_data))
            y_vals = recent_data['MA_7'].values
            
            # Remove NaN values
            valid_idx = ~np.isnan(y_vals)
            if np.sum(valid_idx) < 3:
                return self._create_error_figure("Insufficient valid data for forecasting")
            
            x_vals = x_vals[valid_idx]
            y_vals = y_vals[valid_idx]
            
            # Linear regression for trend
            if len(x_vals) >= 2:
                slope = np.polyfit(x_vals, y_vals, 1)[0]
                last_value = y_vals[-1]
                
                # Generate forecast
                forecast_dates = pd.date_range(
                    start=country_data['Date'].iloc[-1] + pd.Timedelta(days=1),
                    periods=forecast_days,
                    freq='D'
                )
                
                forecast_values = [last_value + slope * i for i in range(1, forecast_days + 1)]
                
                # Create figure
                fig = go.Figure()
                
                # Historical data
                fig.add_trace(go.Scatter(
                    x=country_data['Date'],
                    y=country_data[metric],
                    mode='lines',
                    name='Actual Data',
                    line=dict(color='blue', width=2)
                ))
                
                # Moving average
                fig.add_trace(go.Scatter(
                    x=country_data['Date'],
                    y=country_data['MA_7'],
                    mode='lines',
                    name='7-day Average',
                    line=dict(color='orange', width=2)
                ))
                
                # Forecast
                fig.add_trace(go.Scatter(
                    x=forecast_dates,
                    y=forecast_values,
                    mode='lines+markers',
                    name='Forecast',
                    line=dict(color='red', width=2, dash='dash'),
                    marker=dict(size=6)
                ))
                
                fig.update_layout(
                    title=f'{metric} Forecast for {country} ({forecast_days} days)',
                    xaxis_title='Date',
                    yaxis_title=f'{metric} Cases',
                    height=400,
                    hovermode='x unified'
                )
                
                return fig
            else:
                return self._create_error_figure("Unable to calculate trend")
                
        except Exception as e:
            return self._create_error_figure(f"Error creating forecast: {str(e)}")
    
    def create_growth_analysis(self, data, country, metric):
        """Create growth rate analysis"""
        try:
            country_data = data[data['Country/Region'] == country].sort_values('Date')
            
            if len(country_data) < 7:
                return self._create_error_figure("Insufficient data for growth analysis")
            
            # Calculate daily growth rates
            country_data = country_data.copy()
            country_data['Growth_Rate'] = country_data[metric].pct_change() * 100
            country_data['Growth_Rate_7d'] = country_data['Growth_Rate'].rolling(window=7).mean()
            
            # Create figure
            fig = make_subplots(
                rows=2, cols=1,
                subplot_titles=['Daily Growth Rate (%)', 'Growth Rate Trend (7-day average)'],
                vertical_spacing=0.1
            )
            
            # Daily growth rate
            fig.add_trace(
                go.Scatter(
                    x=country_data['Date'],
                    y=country_data['Growth_Rate'],
                    mode='lines',
                    name='Daily Growth',
                    line=dict(color='lightblue', width=1)
                ),
                row=1, col=1
            )
            
            # 7-day average growth rate
            fig.add_trace(
                go.Scatter(
                    x=country_data['Date'],
                    y=country_data['Growth_Rate_7d'],
                    mode='lines',
                    name='7-day Average',
                    line=dict(color='darkblue', width=2)
                ),
                row=2, col=1
            )
            
            # Add zero line
            fig.add_hline(y=0, line_dash="dash", line_color="red", row=1, col=1)
            fig.add_hline(y=0, line_dash="dash", line_color="red", row=2, col=1)
            
            fig.update_layout(
                title=f'Growth Rate Analysis for {country}',
                height=500,
                showlegend=False
            )
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating growth analysis: {str(e)}")
    
    def calculate_forecast_accuracy(self, data, country, metric):
        """Calculate forecast accuracy metrics"""
        try:
            country_data = data[data['Country/Region'] == country].sort_values('Date')
            
            if len(country_data) < 14:
                return {}
            
            recent_data = country_data.tail(14)
            
            # Calculate trends
            trend_7d = recent_data[metric].tail(7).mean() - recent_data[metric].head(7).mean()
            trend_14d = recent_data[metric].iloc[-1] - recent_data[metric].iloc[0]
            
            # Growth rate
            if recent_data[metric].iloc[0] > 0:
                growth_rate = ((recent_data[metric].iloc[-1] / recent_data[metric].iloc[0]) - 1) * 100
            else:
                growth_rate = 0
            
            # Volatility (standard deviation of daily changes)
            daily_changes = recent_data[metric].diff().dropna()
            volatility = daily_changes.std()
            
            return {
                'trend_7d': f"{trend_7d:+.0f}",
                'trend_14d': f"{trend_14d:+.0f}",
                'growth_rate': f"{growth_rate:+.2f}%",
                'volatility': f"{volatility:.0f}"
            }
            
        except Exception:
            return {}
    
    def create_risk_assessment(self, data):
        """Create risk assessment data"""
        try:
            risk_data = data.copy()
            
            # Calculate risk factors
            risk_data['Case_Rate'] = risk_data.get('Cases per Million', 0)
            risk_data['Death_Rate'] = risk_data.get('Deaths per Million', 0)
            risk_data['Mortality_Risk'] = risk_data['Mortality Rate']
            
            # Normalize risk factors (0-100 scale)
            for col in ['Case_Rate', 'Death_Rate', 'Mortality_Risk']:
                if col in risk_data.columns:
                    max_val = risk_data[col].max()
                    if max_val > 0:
                        risk_data[f'{col}_norm'] = (risk_data[col] / max_val) * 100
                    else:
                        risk_data[f'{col}_norm'] = 0
            
            # Calculate composite risk score
            risk_data['Risk_Score'] = (
                risk_data.get('Case_Rate_norm', 0) * 0.4 +
                risk_data.get('Death_Rate_norm', 0) * 0.3 +
                risk_data.get('Mortality_Risk_norm', 0) * 0.3
            )
            
            return risk_data
            
        except Exception as e:
            return data
    
    def create_risk_heatmap(self, risk_data):
        """Create risk assessment heatmap"""
        try:
            # Get top 50 countries by risk score
            top_risk = risk_data.nlargest(50, 'Risk_Score')
            
            # Create risk categories
            top_risk = top_risk.copy()
            top_risk['Risk_Category'] = pd.cut(
                top_risk['Risk_Score'],
                bins=[0, 25, 50, 75, 100],
                labels=['Low', 'Moderate', 'High', 'Critical']
            )
            
            # Create heatmap
            fig = px.scatter(
                top_risk,
                x='Case_Rate_norm',
                y='Death_Rate_norm',
                size='Risk_Score',
                color='Risk_Category',
                hover_name='Country/Region',
                hover_data=['Risk_Score'],
                title='COVID-19 Risk Assessment Matrix',
                labels={
                    'Case_Rate_norm': 'Case Rate (Normalized)',
                    'Death_Rate_norm': 'Death Rate (Normalized)'
                },
                color_discrete_map={
                    'Low': 'green',
                    'Moderate': 'yellow',
                    'High': 'orange',
                    'Critical': 'red'
                }
            )
            
            fig.update_layout(height=500)
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating risk heatmap: {str(e)}")
    
    def get_risk_summary(self, risk_data):
        """Get risk summary by categories"""
        try:
            # Create risk categories
            risk_data = risk_data.copy()
            conditions = [
                risk_data['Risk_Score'] <= 25,
                (risk_data['Risk_Score'] > 25) & (risk_data['Risk_Score'] <= 50),
                (risk_data['Risk_Score'] > 50) & (risk_data['Risk_Score'] <= 75),
                risk_data['Risk_Score'] > 75
            ]
            choices = ['Low Risk', 'Moderate Risk', 'High Risk', 'Critical Risk']
            risk_data['Risk_Category'] = np.select(conditions, choices, default='Unknown')
            
            # Group by risk category
            summary = {}
            for category in choices:
                countries = risk_data[risk_data['Risk_Category'] == category]['Country/Region'].tolist()
                summary[category] = sorted(countries)
            
            return summary
            
        except Exception:
            return {}
    
    def create_correlation_matrix(self, data):
        """Create correlation matrix of key metrics"""
        try:
            # Select numeric columns for correlation
            numeric_cols = ['Confirmed', 'Deaths', 'Recovered', 'Mortality Rate', 'Recovery Rate']
            available_cols = [col for col in numeric_cols if col in data.columns]
            
            if len(available_cols) < 2:
                return self._create_error_figure("Insufficient data for correlation analysis")
            
            # Calculate correlation matrix
            corr_matrix = data[available_cols].corr()
            
            # Create heatmap
            fig = go.Figure(data=go.Heatmap(
                z=corr_matrix.values,
                x=corr_matrix.columns,
                y=corr_matrix.columns,
                colorscale='RdBu',
                zmid=0,
                text=corr_matrix.round(2).values,
                texttemplate="%{text}",
                textfont={"size": 12},
                showscale=True,
                colorbar=dict(title="Correlation")
            ))
            
            fig.update_layout(
                title='Correlation Matrix of COVID-19 Metrics',
                height=400,
                xaxis={'side': 'bottom'},
                yaxis={'side': 'left'}
            )
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating correlation matrix: {str(e)}")
    
    def create_population_analysis(self, data):
        """Create population vs cases analysis"""
        try:
            # Filter countries with population data
            pop_data = data[data['Population'].notna()].copy()
            
            if len(pop_data) < 10:
                return self._create_error_figure("Insufficient population data")
            
            # Calculate population density proxy (cases per capita)
            pop_data['Cases_per_Capita'] = pop_data['Confirmed'] / pop_data['Population']
            
            # Create scatter plot
            fig = px.scatter(
                pop_data,
                x='Population',
                y='Confirmed',
                size='Cases_per_Capita',
                color='Mortality Rate',
                hover_name='Country/Region',
                title='Population vs COVID-19 Cases',
                labels={
                    'Population': 'Population',
                    'Confirmed': 'Confirmed Cases'
                },
                log_x=True,
                log_y=True
            )
            
            fig.update_layout(height=400)
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating population analysis: {str(e)}")
    
    def detect_outbreaks(self, data, days_back=14):
        """Detect potential outbreaks based on recent trends"""
        try:
            recent_date = data['Date'].max()
            cutoff_date = recent_date - pd.Timedelta(days=days_back)
            
            recent_data = data[data['Date'] >= cutoff_date]
            
            # Calculate growth rates for each country
            outbreak_alerts = []
            
            for country in recent_data['Country/Region'].unique():
                country_data = recent_data[recent_data['Country/Region'] == country].sort_values('Date')
                
                if len(country_data) >= 7:
                    # Calculate recent growth
                    recent_cases = country_data['Confirmed'].iloc[-1]
                    week_ago_cases = country_data['Confirmed'].iloc[-8] if len(country_data) >= 8 else country_data['Confirmed'].iloc[0]
                    
                    if week_ago_cases > 0:
                        growth_rate = ((recent_cases - week_ago_cases) / week_ago_cases) * 100
                        
                        # Check for significant increase (>50% growth in recent period)
                        if growth_rate > 50 and recent_cases > 1000:
                            outbreak_alerts.append({
                                'Country': country,
                                'Growth Rate (%)': round(growth_rate, 2),
                                'Recent Cases': int(recent_cases),
                                'Week Ago Cases': int(week_ago_cases),
                                'Alert Level': 'High' if growth_rate > 100 else 'Moderate'
                            })
            
            return sorted(outbreak_alerts, key=lambda x: x['Growth Rate (%)'], reverse=True)
            
        except Exception:
            return []

    def _create_error_figure(self, error_message):
        """Create error figure when visualization fails"""
        fig = go.Figure()
        fig.add_annotation(
            text=error_message,
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            xanchor='center', yanchor='middle',
            showarrow=False,
            font=dict(size=16, color="red")
        )
        fig.update_layout(
            title="Visualization Error",
            height=400,
            showlegend=False
        )
        return fig
