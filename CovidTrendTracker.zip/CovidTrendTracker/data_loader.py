import pandas as pd
import requests
from io import StringIO
import streamlit as st
from datetime import datetime
import numpy as np

class DataLoader:
    def __init__(self):
        # Johns Hopkins COVID-19 data URLs
        self.base_url = "https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/"
        self.confirmed_url = self.base_url + "time_series_covid19_confirmed_global.csv"
        self.deaths_url = self.base_url + "time_series_covid19_deaths_global.csv"
        self.recovered_url = self.base_url + "time_series_covid19_recovered_global.csv"
        
        # Population data for per capita calculations
        self.population_data = {
            'China': 1439323776,
            'India': 1380004385,
            'United States': 331002651,
            'US': 331002651,
            'Indonesia': 273523615,
            'Pakistan': 220892340,
            'Brazil': 212559417,
            'Nigeria': 206139589,
            'Bangladesh': 164689383,
            'Russia': 145934462,
            'Mexico': 128932753,
            'Japan': 126476461,
            'Ethiopia': 114963588,
            'Philippines': 109581078,
            'Egypt': 102334404,
            'Vietnam': 97338579,
            'Turkey': 84339067,
            'Iran': 83992949,
            'Germany': 83783942,
            'Thailand': 69799978,
            'United Kingdom': 67886011,
            'France': 65273511,
            'Italy': 60461826,
            'Tanzania': 59734218,
            'South Africa': 59308690,
            'Myanmar': 54409800,
            'Kenya': 53771296,
            'South Korea': 51269185,
            'Colombia': 50882891,
            'Spain': 46754778,
            'Uganda': 45741007,
            'Argentina': 45195774,
            'Algeria': 43851044,
            'Sudan': 43849260,
            'Ukraine': 43733762,
            'Iraq': 40222493,
            'Afghanistan': 38928346,
            'Poland': 37846611,
            'Canada': 37742154,
            'Morocco': 36910560,
            'Saudi Arabia': 34813871,
            'Uzbekistan': 33469203,
            'Peru': 32971854,
            'Angola': 32866272,
            'Malaysia': 32365999,
            'Mozambique': 31255435,
            'Ghana': 31072940,
            'Yemen': 29825964,
            'Nepal': 29136808,
            'Venezuela': 28435940,
            'Madagascar': 27691018,
            'Cameroon': 26545863,
            'North Korea': 25778816,
            'Australia': 25499884,
            'Taiwan': 23816775,
            'Sri Lanka': 21413249,
            'Burkina Faso': 20903273,
            'Mali': 20250833,
            'Romania': 19237691,
            'Malawi': 19129952,
            'Chile': 19116201,
            'Kazakhstan': 18776707,
            'Zambia': 18383955,
            'Guatemala': 17915568,
            'Ecuador': 17643054,
            'Syria': 17500658,
            'Netherlands': 17134872,
            'Senegal': 16743927,
            'Cambodia': 16718965,
            'Chad': 16425864,
            'Somalia': 15893222,
            'Zimbabwe': 14862924,
            'Guinea': 13132795,
            'Rwanda': 12952218,
            'Benin': 12123200,
            'Burundi': 11890784,
            'Tunisia': 11818619,
            'Bolivia': 11673021,
            'Belgium': 11589623,
            'Haiti': 11402528,
            'Cuba': 11326616,
            'South Sudan': 11193725,
            'Dominican Republic': 10847910,
            'Czech Republic': 10708981,
            'Greece': 10423054,
            'Jordan': 10203134,
            'Portugal': 10196709,
            'Azerbaijan': 10139177,
            'Sweden': 10099265,
            'Honduras': 9904607,
            'United Arab Emirates': 9890402,
            'Hungary': 9660351,
            'Tajikistan': 9537645,
            'Belarus': 9449323,
            'Austria': 9006398,
            'Papua New Guinea': 8947024,
            'Serbia': 8737371,
            'Israel': 8655535,
            'Switzerland': 8654622,
            'Togo': 8278724,
            'Sierra Leone': 7976983,
            'Laos': 7275560,
            'Paraguay': 7132538,
            'Bulgaria': 6948445,
            'Libya': 6871292,
            'Lebanon': 6825445,
            'Nicaragua': 6624554,
            'Kyrgyzstan': 6524195,
            'El Salvador': 6486205,
            'Turkmenistan': 6031200,
            'Singapore': 5850342,
            'Denmark': 5792202,
            'Finland': 5540720,
            'Congo': 5518087,
            'Slovakia': 5459642,
            'Norway': 5421241,
            'Oman': 5106626,
            'Palestine': 5101414,
            'Costa Rica': 5094118,
            'Liberia': 5057681,
            'Ireland': 4937786,
            'Central African Republic': 4829767,
            'New Zealand': 4822233,
            'Mauritania': 4649658,
            'Panama': 4314767,
            'Kuwait': 4270571,
            'Croatia': 4105267,
            'Moldova': 4033963,
            'Georgia': 3989167,
            'Eritrea': 3546421,
            'Uruguay': 3473730,
            'Bosnia and Herzegovina': 3280819,
            'Mongolia': 3278290,
            'Armenia': 2963243,
            'Jamaica': 2961167,
            'Qatar': 2881053,
            'Albania': 2877797,
            'Puerto Rico': 2860853,
            'Lithuania': 2722289,
            'Namibia': 2540905,
            'Gambia': 2416668,
            'Botswana': 2351627,
            'Gabon': 2225734,
            'Lesotho': 2142249,
            'North Macedonia': 2083374,
            'Slovenia': 2078938,
            'Guinea-Bissau': 1968001,
            'Latvia': 1886198,
            'Bahrain': 1701575,
            'Equatorial Guinea': 1402985,
            'Trinidad and Tobago': 1399488,
            'Estonia': 1326535,
            'East Timor': 1318445,
            'Mauritius': 1271768,
            'Cyprus': 1207359,
            'Eswatini': 1160164,
            'Djibouti': 988000,
            'Fiji': 896445,
            'Reunion': 895312,
            'Comoros': 869601,
            'Guyana': 786552,
            'Bhutan': 771608,
            'Solomon Islands': 686884,
            'Macao': 649335,
            'Montenegro': 628066,
            'Luxembourg': 625978,
            'Western Sahara': 597339,
            'Suriname': 586632,
            'Cape Verde': 555987,
            'Maldives': 540544,
            'Malta': 441543,
            'Brunei': 437479,
            'Guadeloupe': 400124,
            'Belize': 397628,
            'Bahamas': 393244,
            'Martinique': 375265,
            'Iceland': 341243,
            'Vanuatu': 307145,
            'French Guiana': 298682,
            'Barbados': 287375,
            'New Caledonia': 285498,
            'French Polynesia': 280908,
            'Mayotte': 272815,
            'Sao Tome and Principe': 219159,
            'Samoa': 198414,
            'Saint Lucia': 183627,
            'Channel Islands': 173863,
            'Guam': 168775,
            'Curacao': 164093,
            'Kiribati': 119449,
            'Micronesia': 115023,
            'Grenada': 112523,
            'Saint Vincent and the Grenadines': 110940,
            'Aruba': 106766,
            'Tonga': 105695,
            'United States Virgin Islands': 104425,
            'Seychelles': 98347,
            'Antigua and Barbuda': 97929,
            'Isle of Man': 85033,
            'Andorra': 77265,
            'Dominica': 71986,
            'Cayman Islands': 65722,
            'Bermuda': 62278,
            'Marshall Islands': 59190,
            'Northern Mariana Islands': 57559,
            'Greenland': 56770,
            'American Samoa': 55191,
            'Saint Kitts and Nevis': 53199,
            'Faroe Islands': 48863,
            'Sint Maarten': 42876,
            'Monaco': 39242,
            'Turks and Caicos': 38717,
            'Saint Martin': 38666,
            'Liechtenstein': 38128,
            'San Marino': 33931,
            'Gibraltar': 33691,
            'British Virgin Islands': 30231,
            'Caribbean Netherlands': 26223,
            'Palau': 18094,
            'Cook Islands': 17564,
            'Anguilla': 15003,
            'Tuvalu': 11792,
            'Wallis and Futuna': 11239,
            'Nauru': 10824,
            'Saint Barthelemy': 9877,
            'Saint Helena': 6077,
            'Saint Pierre Miquelon': 5794,
            'Montserrat': 4992,
            'Falkland Islands': 3480,
            'Niue': 1626,
            'Tokelau': 1357,
            'Holy See': 801
        }
    
    @st.cache_data(ttl=3600)  # Cache for 1 hour
    def load_data(_self):
        """Load and process COVID-19 data from Johns Hopkins repository"""
        try:
            # Load confirmed cases
            confirmed_df = _self._fetch_data(_self.confirmed_url)
            if confirmed_df is None:
                return None
            
            # Load deaths
            deaths_df = _self._fetch_data(_self.deaths_url)
            if deaths_df is None:
                return None
            
            # Load recovered (note: this dataset was discontinued in March 2023)
            recovered_df = _self._fetch_data(_self.recovered_url)
            
            # Process and combine data
            processed_data = _self._process_data(confirmed_df, deaths_df, recovered_df)
            
            return processed_data
            
        except Exception as e:
            st.error(f"Error loading data: {str(e)}")
            return None
    
    def _fetch_data(self, url):
        """Fetch data from URL"""
        try:
            response = requests.get(url, timeout=30)
            response.raise_for_status()
            
            # Read CSV
            df = pd.read_csv(StringIO(response.text))
            return df
            
        except requests.exceptions.RequestException as e:
            st.error(f"Error fetching data from {url}: {str(e)}")
            return None
        except Exception as e:
            st.error(f"Error processing data: {str(e)}")
            return None
    
    def _process_data(self, confirmed_df, deaths_df, recovered_df):
        """Process and combine COVID-19 datasets"""
        try:
            # Melt confirmed cases
            confirmed_melted = self._melt_data(confirmed_df, 'Confirmed')
            
            # Melt deaths
            deaths_melted = self._melt_data(deaths_df, 'Deaths')
            
            # Melt recovered (if available)
            if recovered_df is not None:
                recovered_melted = self._melt_data(recovered_df, 'Recovered')
            else:
                # Create dummy recovered data
                recovered_melted = confirmed_melted.copy()
                recovered_melted['Recovered'] = 0
                recovered_melted = recovered_melted[['Country/Region', 'Date', 'Recovered']]
            
            # Merge datasets
            merged_df = confirmed_melted.merge(
                deaths_melted, 
                on=['Country/Region', 'Date'], 
                how='outer'
            )
            
            merged_df = merged_df.merge(
                recovered_melted,
                on=['Country/Region', 'Date'],
                how='outer'
            )
            
            # Fill missing values
            merged_df['Confirmed'] = merged_df['Confirmed'].fillna(0)
            merged_df['Deaths'] = merged_df['Deaths'].fillna(0)
            merged_df['Recovered'] = merged_df['Recovered'].fillna(0)
            
            # Add population data and calculate per capita metrics
            merged_df['Population'] = merged_df['Country/Region'].map(self.population_data)
            merged_df['Cases per Million'] = np.where(
                merged_df['Population'].notna(),
                (merged_df['Confirmed'] / merged_df['Population'] * 1000000).round(2),
                np.nan
            )
            merged_df['Deaths per Million'] = np.where(
                merged_df['Population'].notna(),
                (merged_df['Deaths'] / merged_df['Population'] * 1000000).round(2),
                np.nan
            )
            
            # Calculate daily new cases
            merged_df = merged_df.sort_values(['Country/Region', 'Date'])
            merged_df['Daily New Confirmed'] = merged_df.groupby('Country/Region')['Confirmed'].diff().fillna(0)
            merged_df['Daily New Deaths'] = merged_df.groupby('Country/Region')['Deaths'].diff().fillna(0)
            merged_df['Daily New Recovered'] = merged_df.groupby('Country/Region')['Recovered'].diff().fillna(0)
            
            # Ensure no negative values for daily cases
            merged_df['Daily New Confirmed'] = merged_df['Daily New Confirmed'].clip(lower=0)
            merged_df['Daily New Deaths'] = merged_df['Daily New Deaths'].clip(lower=0)
            merged_df['Daily New Recovered'] = merged_df['Daily New Recovered'].clip(lower=0)
            
            # Calculate mortality and recovery rates
            merged_df['Mortality Rate'] = np.where(
                merged_df['Confirmed'] > 0,
                (merged_df['Deaths'] / merged_df['Confirmed'] * 100).round(2),
                0
            )
            merged_df['Recovery Rate'] = np.where(
                merged_df['Confirmed'] > 0,
                (merged_df['Recovered'] / merged_df['Confirmed'] * 100).round(2),
                0
            )
            
            # Calculate additional advanced metrics
            merged_df['Active Cases'] = merged_df['Confirmed'] - merged_df['Deaths'] - merged_df['Recovered']
            merged_df['Case Fatality Rate'] = merged_df['Mortality Rate']  # Alias for clarity
            
            # Calculate trend indicators
            merged_df = merged_df.sort_values(['Country/Region', 'Date'])
            
            # 7-day rolling averages for smoothing
            for metric in ['Confirmed', 'Deaths', 'Recovered']:
                merged_df[f'{metric}_7d_avg'] = merged_df.groupby('Country/Region')[metric].rolling(
                    window=7, min_periods=1
                ).mean().reset_index(0, drop=True)
            
            # Calculate acceleration (second derivative)
            merged_df['Daily_Change_Confirmed'] = merged_df.groupby('Country/Region')['Daily New Confirmed'].diff()
            merged_df['Acceleration'] = merged_df['Daily_Change_Confirmed'].fillna(0)
            
            # Calculate testing positivity rate proxy (if available)
            merged_df['Active_Rate'] = np.where(
                merged_df['Confirmed'] > 0,
                (merged_df['Active Cases'] / merged_df['Confirmed'] * 100).round(2),
                0
            )
            
            # Calculate epidemic curve metrics
            merged_df['Days_Since_First_Case'] = merged_df.groupby('Country/Region')['Date'].rank(method='first') - 1
            
            # Peak detection indicator
            merged_df['Is_Peak'] = False
            for country in merged_df['Country/Region'].unique():
                country_mask = merged_df['Country/Region'] == country
                country_data = merged_df[country_mask].sort_values('Date')
                if len(country_data) > 0:
                    peak_idx = country_data['Daily New Confirmed'].idxmax()
                    merged_df.loc[peak_idx, 'Is_Peak'] = True
            
            # Sort by date and country
            merged_df = merged_df.sort_values(['Date', 'Country/Region'])
            
            return merged_df
            
        except Exception as e:
            st.error(f"Error processing data: {str(e)}")
            return None
    
    def _melt_data(self, df, value_name):
        """Convert wide format to long format"""
        try:
            # Get date columns (skip first 4 columns: Province/State, Country/Region, Lat, Long)
            date_columns = df.columns[4:]
            
            # Group by Country/Region and sum (to handle multiple provinces)
            df_grouped = df.groupby('Country/Region')[date_columns].sum().reset_index()
            
            # Melt the dataframe
            melted_df = df_grouped.melt(
                id_vars=['Country/Region'],
                value_vars=date_columns,
                var_name='Date',
                value_name=value_name
            )
            
            # Convert date strings to datetime
            melted_df['Date'] = pd.to_datetime(melted_df['Date'])
            
            # Ensure numeric values
            melted_df[value_name] = pd.to_numeric(melted_df[value_name], errors='coerce').fillna(0)
            
            return melted_df
            
        except Exception as e:
            st.error(f"Error melting data: {str(e)}")
            return None
