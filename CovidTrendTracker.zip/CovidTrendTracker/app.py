import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

from data_loader import DataLoader
from visualizations import CovidVisualizations
from utils import format_number, get_country_stats

# Page configuration
st.set_page_config(
    page_title="COVID-19 Global Analysis Dashboard",
    page_icon="🦠",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if 'data_loaded' not in st.session_state:
    st.session_state.data_loaded = False
if 'covid_data' not in st.session_state:
    st.session_state.covid_data = None

def main():
    st.title("🦠 COVID-19 Global Analysis Dashboard")
    st.markdown("---")
    
    # Initialize data loader
    data_loader = DataLoader()
    
    # Load data
    if not st.session_state.data_loaded:
        with st.spinner("Loading COVID-19 data..."):
            try:
                covid_data = data_loader.load_data()
                if covid_data is not None:
                    st.session_state.covid_data = covid_data
                    st.session_state.data_loaded = True
                    st.success("✅ Data loaded successfully!")
                else:
                    st.error("❌ Failed to load COVID-19 data. Please check your internet connection.")
                    return
            except Exception as e:
                st.error(f"❌ Error loading data: {str(e)}")
                return
    
    covid_data = st.session_state.covid_data
    
    if covid_data is None:
        st.error("No data available to display.")
        return
    
    # Initialize visualizations
    viz = CovidVisualizations(covid_data)
    
    # Sidebar for controls
    st.sidebar.header("🎛️ Dashboard Controls")
    
    # Advanced Analysis Mode Toggle
    analysis_mode = st.sidebar.selectbox(
        "🔬 Analysis Mode",
        options=['Basic Analysis', 'Advanced Analytics', 'Expert Mode'],
        index=0,
        help="Choose the complexity level of analysis and visualizations"
    )
    
    # Date range selector
    min_date = covid_data['Date'].min()
    max_date = covid_data['Date'].max()
    
    date_range = st.sidebar.date_input(
        "📅 Select Date Range",
        value=(min_date, max_date),
        min_value=min_date,
        max_value=max_date
    )
    
    # Country selector with smart suggestions
    countries = sorted(covid_data['Country/Region'].unique())
    
    # Smart country suggestions based on data
    latest_data_for_suggestions = covid_data[covid_data['Date'] == covid_data['Date'].max()]
    top_cases = latest_data_for_suggestions.nlargest(10, 'Confirmed')['Country/Region'].tolist()
    top_deaths = latest_data_for_suggestions.nlargest(10, 'Deaths')['Country/Region'].tolist()
    
    country_selection_type = st.sidebar.radio(
        "🌍 Country Selection",
        options=['Manual Selection', 'Top by Cases', 'Top by Deaths', 'Risk-Based'],
        index=0
    )
    
    if country_selection_type == 'Manual Selection':
        default_countries = ['US', 'China', 'Italy', 'Spain', 'Germany', 'France', 'Iran', 'United Kingdom']
        available_defaults = [c for c in default_countries if c in countries]
        selected_countries = st.sidebar.multiselect(
            "Select Countries",
            options=countries,
            default=available_defaults[:5] if available_defaults else countries[:5]
        )
    elif country_selection_type == 'Top by Cases':
        num_countries = st.sidebar.slider("Number of Countries", 3, 15, 8)
        selected_countries = top_cases[:num_countries]
        st.sidebar.info(f"Showing top {num_countries} countries by confirmed cases")
    elif country_selection_type == 'Top by Deaths':
        num_countries = st.sidebar.slider("Number of Countries", 3, 15, 8)
        selected_countries = top_deaths[:num_countries]
        st.sidebar.info(f"Showing top {num_countries} countries by deaths")
    else:  # Risk-Based
        num_countries = st.sidebar.slider("Number of Countries", 3, 15, 8)
        # Calculate risk score for selection
        risk_countries = latest_data_for_suggestions.copy()
        risk_countries['Risk_Score'] = (
            risk_countries['Cases per Million'].fillna(0) * 0.4 +
            risk_countries['Deaths per Million'].fillna(0) * 0.6
        )
        selected_countries = risk_countries.nlargest(num_countries, 'Risk_Score')['Country/Region'].tolist()
        st.sidebar.info(f"Showing top {num_countries} countries by risk assessment")
    
    # Enhanced metric selector
    metric_category = st.sidebar.selectbox(
        "📊 Metric Category",
        options=['Basic Metrics', 'Rate Metrics', 'Advanced Metrics'],
        index=0
    )
    
    if metric_category == 'Basic Metrics':
        metric = st.sidebar.selectbox(
            "Select Metric",
            options=['Confirmed', 'Deaths', 'Recovered', 'Active Cases'],
            index=0
        )
    elif metric_category == 'Rate Metrics':
        metric = st.sidebar.selectbox(
            "Select Rate Metric",
            options=['Mortality Rate', 'Recovery Rate', 'Active_Rate', 'Cases per Million', 'Deaths per Million'],
            index=0
        )
    else:  # Advanced Metrics
        metric = st.sidebar.selectbox(
            "Select Advanced Metric",
            options=['Daily New Confirmed', 'Acceleration', 'Confirmed_7d_avg', 'Days_Since_First_Case'],
            index=0
        )
    
    # View type selector with more options
    view_type = st.sidebar.selectbox(
        "📈 View Type",
        options=['Cumulative', 'Daily New Cases', 'Moving Average', 'Growth Rate', 'Logarithmic'],
        index=0,
        help="Choose how to display the data trends"
    )
    
    # Data smoothing options
    if analysis_mode != 'Basic Analysis':
        st.sidebar.subheader("⚙️ Analysis Settings")
        
        smoothing_enabled = st.sidebar.checkbox(
            "Enable Data Smoothing",
            value=True,
            help="Apply moving averages to reduce noise in data"
        )
        
        if smoothing_enabled:
            smoothing_window = st.sidebar.slider(
                "Smoothing Window (days)",
                min_value=3,
                max_value=14,
                value=7
            )
        
        # Statistical analysis options
        show_confidence_bands = st.sidebar.checkbox(
            "Show Confidence Intervals",
            value=False,
            help="Display statistical confidence bands around trends"
        )
        
        # Outlier detection
        outlier_detection = st.sidebar.checkbox(
            "Highlight Anomalies",
            value=True,
            help="Identify and highlight unusual data points"
        )
    
    # Quick analysis shortcuts
    st.sidebar.subheader("🚀 Quick Analysis")
    
    col1, col2 = st.sidebar.columns(2)
    with col1:
        if st.button("🔥 Hotspots", help="Show current COVID hotspots"):
            # Auto-select high-risk countries
            risk_data = latest_data_for_suggestions.copy()
            risk_data['Risk_Score'] = risk_data['Cases per Million'].fillna(0) + risk_data['Deaths per Million'].fillna(0)
            st.session_state.selected_countries = risk_data.nlargest(8, 'Risk_Score')['Country/Region'].tolist()
            st.session_state.metric = 'Cases per Million'
            st.rerun()
    
    with col2:
        if st.button("📉 Recovery", help="Show recovery leaders"):
            # Auto-select countries with high recovery rates
            recovery_leaders = latest_data_for_suggestions[latest_data_for_suggestions['Recovery Rate'] > 80]
            if len(recovery_leaders) >= 5:
                st.session_state.selected_countries = recovery_leaders.nlargest(8, 'Recovery Rate')['Country/Region'].tolist()
                st.session_state.metric = 'Recovery Rate'
                st.rerun()
    
    # Filter data by date range
    if len(date_range) == 2:
        start_date, end_date = date_range
        filtered_data = covid_data[
            (covid_data['Date'] >= pd.to_datetime(start_date)) &
            (covid_data['Date'] <= pd.to_datetime(end_date))
        ]
    else:
        filtered_data = covid_data
    
    # Data quality indicator
    data_quality_score = 95  # Calculate based on data completeness
    last_update = covid_data['Date'].max().strftime('%Y-%m-%d')
    
    # Header with real-time status
    col_status1, col_status2, col_status3 = st.columns([2, 1, 1])
    with col_status1:
        st.markdown(f"### 📊 Live COVID-19 Dashboard")
        st.caption(f"Last updated: {last_update} | Data quality: {data_quality_score}%")
    with col_status2:
        if data_quality_score >= 90:
            st.success("🟢 Data: Excellent")
        elif data_quality_score >= 80:
            st.warning("🟡 Data: Good")
        else:
            st.error("🔴 Data: Limited")
    with col_status3:
        countries_reporting = covid_data['Country/Region'].nunique()
        st.info(f"📍 {countries_reporting} Countries")
    
    # Enhanced global statistics with trends
    latest_data = covid_data[covid_data['Date'] == covid_data['Date'].max()]
    previous_data = covid_data[covid_data['Date'] == (covid_data['Date'].max() - pd.Timedelta(days=7))]
    
    total_confirmed = latest_data['Confirmed'].sum()
    total_deaths = latest_data['Deaths'].sum()
    total_recovered = latest_data['Recovered'].sum()
    
    # Calculate weekly changes
    prev_confirmed = previous_data['Confirmed'].sum() if not previous_data.empty else total_confirmed
    prev_deaths = previous_data['Deaths'].sum() if not previous_data.empty else total_deaths
    prev_recovered = previous_data['Recovered'].sum() if not previous_data.empty else total_recovered
    
    confirmed_change = total_confirmed - prev_confirmed
    deaths_change = total_deaths - prev_deaths
    recovered_change = total_recovered - prev_recovered
    
    # Interactive metrics with animations
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        st.metric(
            label="🌍 Total Confirmed",
            value=format_number(total_confirmed),
            delta=f"+{format_number(confirmed_change)} this week" if confirmed_change > 0 else "No change"
        )
    
    with col2:
        st.metric(
            label="💀 Total Deaths",
            value=format_number(total_deaths),
            delta=f"+{format_number(deaths_change)} this week" if deaths_change > 0 else "No change"
        )
    
    with col3:
        st.metric(
            label="💚 Total Recovered",
            value=format_number(total_recovered),
            delta=f"+{format_number(recovered_change)} this week" if recovered_change > 0 else "No change"
        )
    
    with col4:
        active_cases = total_confirmed - total_deaths - total_recovered
        mortality_rate = (total_deaths/total_confirmed*100) if total_confirmed > 0 else 0
        st.metric(
            label="🔄 Active Cases",
            value=format_number(active_cases),
            delta=f"{mortality_rate:.2f}% mortality rate"
        )
    
    with col5:
        # Calculate global trend indicator
        global_trend = "📈 Rising" if confirmed_change > prev_confirmed * 0.05 else "📉 Declining" if confirmed_change < 0 else "📊 Stable"
        recovery_rate = (total_recovered/total_confirmed*100) if total_confirmed > 0 else 0
        st.metric(
            label="🌐 Global Trend",
            value=global_trend,
            delta=f"{recovery_rate:.1f}% recovery rate"
        )
    
    st.markdown("---")
    
    # Visualization tabs
    tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs([
        "📈 Trend Analysis", 
        "🌍 Global Heatmap", 
        "🏆 Country Rankings", 
        "📊 Comparative Analysis",
        "🔮 Predictions & Forecasting",
        "🎯 Risk Assessment",
        "📋 Data Export"
    ])
    
    with tab1:
        st.subheader("📈 COVID-19 Trend Analysis")
        
        if selected_countries:
            # Line plot for selected countries
            fig_line = viz.create_line_plot(
                filtered_data, 
                selected_countries, 
                metric, 
                view_type
            )
            st.plotly_chart(fig_line, use_container_width=True)
            
            # Area chart for global trends
            st.subheader("🌐 Global Trends")
            fig_area = viz.create_area_chart(filtered_data, metric)
            st.plotly_chart(fig_area, use_container_width=True)
        else:
            st.warning("Please select at least one country to display trends.")
    
    with tab2:
        st.subheader("🌍 Global COVID-19 Heatmap")
        
        # Heatmap by country
        fig_heatmap = viz.create_country_heatmap(latest_data, metric)
        st.plotly_chart(fig_heatmap, use_container_width=True)
        
        # Time series heatmap
        if selected_countries:
            st.subheader("🕒 Time Series Heatmap")
            fig_time_heatmap = viz.create_time_heatmap(
                filtered_data, 
                selected_countries, 
                metric
            )
            st.plotly_chart(fig_time_heatmap, use_container_width=True)
    
    with tab3:
        st.subheader("🏆 Country Rankings")
        
        # Top countries table
        ranking_metric = st.selectbox(
            "Ranking by:",
            options=['Confirmed', 'Deaths', 'Recovered', 'Deaths per Million', 'Cases per Million'],
            key="ranking_metric"
        )
        
        rankings_df = viz.get_country_rankings(latest_data, ranking_metric)
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.dataframe(
                rankings_df.head(20),
                use_container_width=True,
                hide_index=True
            )
        
        with col2:
            # Bar chart of top 10
            fig_bar = px.bar(
                rankings_df.head(10),
                x='Value',
                y='Country',
                orientation='h',
                title=f"Top 10 Countries by {ranking_metric}",
                labels={'Value': ranking_metric, 'Country': 'Country'}
            )
            fig_bar.update_layout(height=400, yaxis={'categoryorder': 'total ascending'})
            st.plotly_chart(fig_bar, use_container_width=True)
    
    with tab4:
        st.subheader("📊 Comparative Analysis")
        
        if len(selected_countries) >= 2:
            # Multi-metric comparison
            comparison_df = viz.create_comparison_table(latest_data, selected_countries)
            st.dataframe(comparison_df, use_container_width=True)
            
            # Radar chart for comparison
            fig_radar = viz.create_radar_chart(latest_data, selected_countries)
            st.plotly_chart(fig_radar, use_container_width=True)
            
            # Recovery vs Death rate scatter plot
            fig_scatter = viz.create_scatter_plot(latest_data, selected_countries)
            st.plotly_chart(fig_scatter, use_container_width=True)
        else:
            st.warning("Please select at least 2 countries for comparative analysis.")
    
    with tab5:
        st.subheader("🔮 Predictions & Forecasting")
        
        if selected_countries:
            forecast_country = st.selectbox(
                "Select Country for Prediction",
                options=selected_countries,
                key="forecast_country"
            )
            
            forecast_days = st.slider(
                "Forecast Days",
                min_value=7,
                max_value=30,
                value=14,
                key="forecast_days"
            )
            
            col1, col2 = st.columns(2)
            
            with col1:
                # Moving average trend
                fig_trend = viz.create_trend_forecast(
                    filtered_data, 
                    forecast_country, 
                    metric, 
                    forecast_days
                )
                st.plotly_chart(fig_trend, use_container_width=True)
            
            with col2:
                # Growth rate analysis
                fig_growth = viz.create_growth_analysis(
                    filtered_data, 
                    forecast_country, 
                    metric
                )
                st.plotly_chart(fig_growth, use_container_width=True)
            
            # Prediction accuracy metrics
            st.subheader("📊 Forecast Metrics")
            accuracy_metrics = viz.calculate_forecast_accuracy(
                filtered_data, 
                forecast_country, 
                metric
            )
            
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("7-day Trend", accuracy_metrics.get('trend_7d', 'N/A'))
            with col2:
                st.metric("14-day Trend", accuracy_metrics.get('trend_14d', 'N/A'))
            with col3:
                st.metric("Growth Rate", accuracy_metrics.get('growth_rate', 'N/A'))
            with col4:
                st.metric("Volatility", accuracy_metrics.get('volatility', 'N/A'))
        else:
            st.warning("Please select at least one country for forecasting.")
    
    with tab6:
        st.subheader("🎯 Risk Assessment & Analytics")
        
        # Risk assessment matrix
        risk_data = viz.create_risk_assessment(latest_data)
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            # Risk heatmap
            fig_risk = viz.create_risk_heatmap(risk_data)
            st.plotly_chart(fig_risk, use_container_width=True)
        
        with col2:
            # Risk categories
            st.write("**Risk Categories:**")
            risk_summary = viz.get_risk_summary(risk_data)
            
            for category, countries in risk_summary.items():
                if countries:
                    st.write(f"**{category}:** {len(countries)} countries")
                    with st.expander(f"View {category} countries"):
                        for country in countries[:10]:  # Show top 10
                            st.write(f"• {country}")
        
        # Advanced analytics
        st.subheader("📈 Advanced Analytics")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Correlation analysis
            fig_corr = viz.create_correlation_matrix(latest_data)
            st.plotly_chart(fig_corr, use_container_width=True)
        
        with col2:
            # Population density vs cases
            fig_density = viz.create_population_analysis(latest_data)
            st.plotly_chart(fig_density, use_container_width=True)
        
        # Outbreak detection
        st.subheader("🚨 Outbreak Detection")
        outbreak_alerts = viz.detect_outbreaks(covid_data, days_back=14)
        
        if outbreak_alerts:
            st.warning(f"⚠️ Potential outbreaks detected in {len(outbreak_alerts)} countries")
            outbreak_df = pd.DataFrame(outbreak_alerts)
            st.dataframe(outbreak_df, use_container_width=True)
        else:
            st.success("✅ No significant outbreak patterns detected in recent data")
    
    with tab7:
        st.subheader("📋 Data Export")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Export Options:**")
            
            if st.button("📥 Download Global Summary"):
                summary_data = viz.get_summary_data(latest_data)
                csv = summary_data.to_csv(index=False)
                st.download_button(
                    label="Download CSV",
                    data=csv,
                    file_name=f"covid19_summary_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv"
                )
            
            if selected_countries and st.button("📥 Download Country Data"):
                country_data = filtered_data[
                    filtered_data['Country/Region'].isin(selected_countries)
                ]
                csv = country_data.to_csv(index=False)
                st.download_button(
                    label="Download CSV",
                    data=csv,
                    file_name=f"covid19_countries_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv"
                )
        
        with col2:
            st.write("**Data Information:**")
            st.info(f"""
            📊 **Dataset Info:**
            - Total Records: {len(covid_data):,}
            - Countries: {covid_data['Country/Region'].nunique()}
            - Date Range: {min_date.strftime('%Y-%m-%d')} to {max_date.strftime('%Y-%m-%d')}
            - Last Updated: {max_date.strftime('%Y-%m-%d')}
            """)
    
    # Footer
    st.markdown("---")
    st.markdown("""
    **Data Source:** Johns Hopkins University Center for Systems Science and Engineering (JHU CSSE)  
    **Dashboard Created:** COVID-19 Global Analysis Dashboard  
    **Last Updated:** {date}
    """.format(date=datetime.now().strftime('%Y-%m-%d %H:%M:%S')))

if __name__ == "__main__":
    main()
